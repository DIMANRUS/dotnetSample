package com.company.product;

import android.os.Bundle;
import android.widget.FrameLayout;
import com.unity3d.player.UnityPlayer;
import com.unity3d.player.UnityPlayerActivity;

public abstract class OverrideUnityActivity extends UnityPlayerActivity {
  public static OverrideUnityActivity instance = null;
  
  protected FrameLayout getUnityFrameLayout() {
    return (FrameLayout)this.mUnityPlayer;
  }
  
  protected abstract void showMainActivity(String paramString);
  
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    instance = this;
  }
  
  protected void onDestroy() {
    super.onDestroy();
    instance = null;
  }
}