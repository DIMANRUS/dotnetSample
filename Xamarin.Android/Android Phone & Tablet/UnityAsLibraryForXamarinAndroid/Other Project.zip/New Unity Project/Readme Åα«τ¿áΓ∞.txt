Так как проект юнити очень много весит, я удалил папку Library, проект откроется, вам только нужно будет добавить на сцену куб и повесить на него скрипты.

Since the Unity project is very heavy, I deleted the Library folder, the project will open, you only need to add a cube to the scene and hang scripts on it. 